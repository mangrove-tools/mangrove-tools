# Ship With a Lead-Dev Agent — Self-serve start

This is a self-paced pack. There are no live sessions.

1. Read `course/CURRICULUM.md` as your roadmap (treat “live session” sections as reading/work blocks).
2. Complete assignments in `course/assignments/` in order.
3. Use phase checklists in `course/checklists/`.
4. Use stack templates in `templates/` to draft your AGENTS.md + lead prompt.
5. Use `course/REVIEW_FORM.md` to score your own work.
6. Optional questions: needlesearchapp@protonmail.com
7. Method article: https://mangrovetools.com/method/

## License (personal)
Personal use for your own products. Do not resell or redistribute this pack as a competing course.
