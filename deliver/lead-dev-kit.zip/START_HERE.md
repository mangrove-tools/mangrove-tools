# Lead-Dev Kit — Start here

Thanks for purchasing.

1. Pick the stack folder under `templates/` that matches your project.
2. Copy that folder’s `AGENTS.md` to your repo root (adapt names).
3. Copy `LEAD_DEV_BUILD_PROMPT.md` into `docs/` in your repo.
4. Fill any `[[BRACKETED]]` placeholders.
5. Paste the lead prompt into a fresh agent session.
6. Read the free method article anytime: https://mangrovetools.com/method/

## License (personal)
Personal use for your own products. Do not resell or redistribute this pack as a competing template kit.
